import React, { Component } from 'react';

export default class Root extends Component {
    render() {
        return (
            <h1>Hello World</h1>
        );
    }
}
